Chef::Log.fatal('The nodejs::iojs recipe has been deprecated. If you need iojs installation pin to cookbook version 3.0.1.')
