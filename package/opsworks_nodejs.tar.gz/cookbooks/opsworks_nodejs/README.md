# opsworks_nodejs

AWS OpsWorks custom cookbook to be used as a helper for Node.js applications. 

# TODOs

1. Create an app user with dropped privileges and do all the steps with that user
