[2018-11-25T18:07:50+00:00] INFO: Processing execute[copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip] action run (/var/chef/runs/10332ca5-2008-4de7-99e5-f2cece49c7d8/local-mode-cache/cache/cookbooks/s3_cli/resources/cp.rb line 41)
[2018-11-25T18:07:50+00:00] INFO: Retrying execution of execute[copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip], 2 attempt(s) left
[2018-11-25T18:07:52+00:00] INFO: Retrying execution of execute[copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip], 1 attempt(s) left
[2018-11-25T18:07:54+00:00] INFO: Retrying execution of execute[copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip], 0 attempt(s) left
 
================================================================================
Error executing action `run` on resource 'execute[copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip]'
================================================================================
 
Errno::ENOENT
-------------
No such file or directory - /usr/local/bin/aws
 
Resource Declaration:
---------------------
# In /var/chef/runs/10332ca5-2008-4de7-99e5-f2cece49c7d8/local-mode-cache/cache/cookbooks/s3_cli/resources/cp.rb
 
41:   execute "copy #{new_resource.s3_source} to #{new_resource.s3_destination}" do
42:     retries new_resource.s3_cli_retries
43:     command s3_cmd
44:     user new_resource.username if new_resource.username
45:     group new_resource.groupname if new_resource.groupname
46:     creates new_resource.s3_creates if new_resource.s3_creates
47:     umask new_resource.s3_umask if new_resource.s3_umask
48:   end
49: end
 
Compiled Resource:
------------------
# Declared in /var/chef/runs/10332ca5-2008-4de7-99e5-f2cece49c7d8/local-mode-cache/cache/cookbooks/s3_cli/resources/cp.rb:41:in `block in class_from_file'
 
execute("copy s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip to /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip") do
action [:run]
retries 3
retry_delay 2
default_guard_interpreter :execute
command "/usr/local/bin/aws s3 cp s3://codepipeline-us-east-1-73425545135/opsworks-try2/SourceArti/uSiyYon.zip /opt/792f0e71-c991-4ff5-9c2c-d1460d9002e0/app.zip "
backup 5
returns 0
declared_type :execute
cookbook_name "opsworks_nodejs"
end
 
Platform:
---------
x86_64-linux
